java -jar $ORDS_HOME/ords.war configdir /u01/ords
java -jar $ORDS_HOME/ords.war nosqladd --pagelimit 27 sales kvstore node1:5000 

cd $KVHOME/examples
java -cp .:$KVHOME/lib/*:$KVHOME/examples/* table.TableAPIExample -host node1 -port 5000 -store kvstore

java -jar $ORDS_HOME/ords.war standalone << EOF &
8080
EOF
