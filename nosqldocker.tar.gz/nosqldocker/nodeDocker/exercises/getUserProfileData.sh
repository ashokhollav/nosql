if [ "$2" = '' ]; then
java -jar $KVHOME/lib/kvstore.jar runadmin -port 5000 -store kvstore -host $1 <<EOF
get table -name UserProfile 
EOF
else
java -jar $KVHOME/lib/kvstore.jar runadmin -port 5000 -store kvstore -host $1 <<EOF
get table -name UserProfile -field id -value ${2}
EOF
fi
