#!/bin/bash
set -e
echo $1
if [ "$1" = 'bash' ]; then
exec $@
else
java -jar $KVHOME/lib/kvstore.jar runadmin -port 5000 -host ${1} -store kvstore load -file ${2}
fi

