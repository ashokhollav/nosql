echo " kvstore metadata catalog"


curl http://localhost:8080/ords/sales/metadata-catalog/

echo "all data of table simpleUsers"

curl http://localhost:8080/ords/sales/metadata-catalog/tables/simpleUsers/

echo "single item of table simpleUsers"

curl http://localhost:8080/ords/sales/metadata-catalog/tables/simpleUsers/item

echo "access via primary key"

curl -L http://localhost:8080/ords/sales/tables/simpleUsers/1

echo "access via compound pk"

curl -L http://localhost:8080/ords/sales/tables/shardUsers/Robertson,Beatrix

echo "partial pk"

curl -L http://localhost:8080/ords/sales/tables/shardUsers/Robertson

echo "access via secondary index"

curl -L http://localhost:8080/ords/sales/tables/simpleUsers/index/simpleIndex/Joel 
  
echo "access via compound index"
  
curl -L http://localhost:8080/ords/sales/tables/simpleUsers/index/compoundIndex/Jameson,Bob
  
echo "access via arrayindex"

curl -L  http://localhost:8080/ords/sales/tables/complexUsers/index/arrayIndex/movies
  
echo "Insert if not present or Update if present (Upsert)"
  
  curl -i -H "Content-Type: application/json" -X PUT -d "{\"userID\": 104, \"firstName\": \"Bob\", \"lastName\": \"Johnson\"}" "http://localhost:8080/ords/sales/tables/simpleUsers/"
  
echo "Insert if Absent"

  curl -i -H "Content-Type: application/json" -X POST -d "{\"userID\": 108, \"firstName\": \"Bob\", \"lastName\": \"Johnson\"}" "http://localhost:8080/ords/sales/tables/simpleUsers/"
  
echo "Insert if present"

  curl -i -H "Content-Type: application/json" -X PUT -d "{\"userID\": 104, \"firstName\": \"Bob\", \"lastName\": \"Johnson\"}" "http://localhost:8080/ords/sales/tables/simpleUsers/104"
    
echo "delete"

  curl -i -X DELETE "http://localhost:8080/ords/sales/tables/simpleUsers/4"
  
echo "delete by partial key"
  
  curl -i -X DELETE "http://localhost:8080/ords/sales/tables/shardUsers/Robertson"
  
echo "create table"
  
  curl -i -H "Content-Type: text/plain" -X POST -d "CREATE TABLE IF NOT EXISTS myUsers  (firstName STRING,lastName STRING,userID INTEGER,PRIMARY KEY (userID))" "http://localhost:8080/ords/sales/ddl/"
  
#echo "poll for last call
  
#curl -i -X GET  "http://localhost:8080/ords/sales/ddl/tasks/48"
  
