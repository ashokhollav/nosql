java -jar $KVHOME/lib/kvstore.jar runadmin -host node1 -port 5000 -store kvstore
