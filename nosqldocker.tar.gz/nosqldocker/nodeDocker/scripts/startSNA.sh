KVHOME=/u01/kvhome/kv-3.3.4
KVROOT=/u01/kvroot
nohup java -jar $KVHOME/lib/kvstore.jar start -root $KVROOT 
