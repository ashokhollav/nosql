#!/bin/bash
set -e
echo $1
KVHOME=/u01/kvhome/kv-3.3.4
if [ "$1" = 'bash' ]; then
exec $@
else
cd /home/oracle/scripts
java -jar $KVHOME/lib/kvstore.jar runadmin -port 5000 -host ${1} load -file ${2}.kvs
fi

