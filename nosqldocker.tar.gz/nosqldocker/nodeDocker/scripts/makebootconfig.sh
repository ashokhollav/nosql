#!/bin/bash
KVHOME=/u01/kvhome/kv-3.3.4
KVROOT=/u01/kvroot
mkdir -p /data/`hostname`
echo "makebootconfig"
java -jar $KVHOME/lib/kvstore.jar makebootconfig \
	-root $KVROOT \
	-store-security none \
	-capacity 1 \
	-harange 5010,5030 \
	-admin 5001 \
	-port 5000 \
	-memory_mb 512 \
	-host `hostname` \
	-storagedir /data/`hostname`
echo "Done bootstrapping"
