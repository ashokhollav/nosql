#!/bin/bash
set -e

export KVHOME=/u01/kvhome/kv-3.3.4
cd /home/oracle/scripts

if [ "$1" = '--help' ]; then
        echo "Usage:"
        echo "docker run -it nosql:<tag> [options]"
	echo "options:"
	echo "plan [adminhost] [configrequired]"
	echo "=====Example: docker run -it nosql:1.0 plan node1 3x1"
        echo "========Available configs"
        echo "===========3x1 => 3 node 1 shard"
        echo "===========4x1 => 4 node 1 shard"
        echo "===========6x2 => 6 node 2 shard"
	echo "make"
	echo "=====Example: docker run -it nosql:1.0 make"
	echo "always start a new node with the make command, this is the default option as well"

elif [ "$1" = 'make' ]; then

echo "hello makebootconfig"
./makebootconfig.sh
./startSNA.sh
elif [ "$1" = 'plan' ]; then
plan='3x1'
if [ "$3" != '' ]; then
plan="$3"
fi
host='node1'
if [ "$2" != '' ]; then
host="$2"
fi
./runScript.sh ${host} ${plan}
else
exec "$@"
cd /home/oracle/exercises
fi
